
let mainContract = undefined;
let token = undefined;

async function handleConnectionRequest(){

    if(window.ethereum && (window.ethereum.isMetaMask == true)) {


        const newAccounts = await ethereum.request({ method: 'eth_requestAccounts', })
        window.web3 = new Web3(window.ethereum);

        const networkId = await window.web3.eth.net.getId();

        initContracts(networkId)


        console.log(newAccounts);
    }else {
        alert("metamask not installed");
    }

}

function initialize() {

    

    const connectButton = document.getElementById("connectButton");
    connectButton.onclick = handleConnectionRequest

    const buyButton = document.getElementById("buyButton");
    buyButton.onclick = handleBuyRequest

    const customerRegistrationButton = document.getElementById("customerRegistrationButton");
    customerRegistrationButton.onclick = handleCustomerRegistrationRequest

    const customerUpdateButton = document.getElementById("customerUpdateButton");
    customerUpdateButton.onclick = handleCustomerUpdateRequest

    const selectItemButton = document.getElementById("selectItemButton");
    selectItemButton.onclick = handleSelectItemRequest

    const checkOutButton = document.getElementById("checkOutButton");
    checkOutButton.onclick = handleCheckOutRequest

    // const viewBillButton = document.getElementById("viewBillButton");
    // const Bill = document.getElementById("getResult");
    // viewBillButton.addEventListener('click', async () => {

    //     const accounts = await window.web3.eth.getAccounts();

    //     const balance = await mainContract.methods.view_Bill().send({ from : accounts[0] });
    //     Bill.innerHTML = balance.valueOf() || 'Not able to View bill';
    // });

    const cusAuthButton = document.getElementById("cusAuthButton");
    cusAuthButton.onclick = handleAuthCusRequest

    const hotelRegistrationButton = document.getElementById("hotelRegistrationButton");
    hotelRegistrationButton.onclick = handleHotelRegistrationRequest

    const hotelUpdateButton = document.getElementById("hotelUpdateButton");
    hotelUpdateButton.onclick = handleHotelUpdateRequest

    
    const addItemButton = document.getElementById("addItemButton");
    addItemButton.onclick = handleAddItemRequest

    const removeItemButton = document.getElementById("removeItemButton");
    removeItemButton.onclick = handleRemoveItemRequest


    const updateItemButton = document.getElementById("updateItemButton");
    updateItemButton.onclick = handleUpdateItemRequest

    const PrepareButton = document.getElementById("PrepareButton");
    PrepareButton.onclick = handlePrepareRequest
    

    const AuthButton = document.getElementById("AuthButton");
    AuthButton.onclick = handleAuthRequest

    const executiveRegistrationButton = document.getElementById("executiveRegistrationButton");
    executiveRegistrationButton.onclick = handleExecRegistrationRequest

    const executiveUpdateButton = document.getElementById("executiveUpdateButton");
    executiveUpdateButton.onclick = handleExecUpdateRequest

    const pickOrderButton = document.getElementById("pickOrderButton");
    pickOrderButton.onclick = handlePickOrderRequest

    const execAuthButton = document.getElementById("execAuthButton");
    execAuthButton.onclick = handleAuthExecRequest

}

function initContracts(networkId){

    $.getJSON('MainContract.json', function(data) {

        try {
            let RegData =  data;
            
            const deployedNetwork = data.networks[networkId];
            
            mainContract = new web3.eth.Contract( RegData.abi, deployedNetwork.address );

            console.log("MainContarct",mainContract);

        } catch (error) {
            alert( `Failed to load web3, accounts contracts. Check console for details.`);
            console.log(error);
        }
    });

    $.getJSON('foodiToken.json', function(data) {

        try {
            let RegData =  data;
            
            const deployedNetwork = data.networks[networkId];
            
            token = new web3.eth.Contract( RegData.abi, deployedNetwork.address );

        

            console.log("foodiToken",token);

        } catch (error) {
            alert( `Failed to load web3, accounts contracts. Check console for details.`);
            console.log(error);
        }
    });

}



async function handleBuyRequest(){

    let tokenValue = document.getElementById("amount");

        let amount = tokenValue.value;


        let accounts = await window.web3.eth.getAccounts();

        try
        
        {

        await mainContract.methods._buyTokens(amount).send({from: accounts[0], value: 10000000000000000000}, function(error, result){
            console.log(result);
            console.log(error);
        });



    } catch (error) {
        alert( `Failed to Buy Token`);
        console.error(error)
    }




}

async function handleCustomerRegistrationRequest(){

    let cusName =  document.getElementById("cusName");
    let cusAddress =  document.getElementById("cusAddress");
    let cusPhone =  document.getElementById("cusPhone");

        let name = cusName.value;
        let address = cusAddress.value;
        let phone  = cusPhone.value;

        let accounts = await window.web3.eth.getAccounts();

        try {
            await mainContract.methods.Register_as_Customer(name,address,phone).send({from: accounts[0]}, function(error, result){
            console.log(result);
            console.log(error);
        });

    } catch (error) {
        alert( `Failed to Register Customer`);
        console.error(error)
    }

}

async function handleHotelRegistrationRequest(){

    let Name =  document.getElementById("HotelName");
    let Address =  document.getElementById("HotelAddress");
    let Phone =  document.getElementById("HotelPhone");

        let name = Name.value;
        let address = Address.value;
        let phone  = Phone.value;

        let accounts = await window.web3.eth.getAccounts();

        try {
            await mainContract.methods.Register_as_Hotel(name,address,phone).send({from: accounts[0]}, function(error, result){
            console.log(result);
            console.log(error);
        });

    } catch (error) {
        alert( `Failed to Register Hotel`);
        console.error(error)
    }

}

async function handleExecRegistrationRequest(){

    let Name =  document.getElementById("execName");
    let Address =  document.getElementById("execAddress");
    let Phone =  document.getElementById("execPhone");

        let name = Name.value;
        let address = Address.value;
        let phone  = Phone.value;

        let accounts = await window.web3.eth.getAccounts();

        try {
            await mainContract.methods.Register_as_Hotel(name,address,phone).send({from: accounts[0]}, function(error, result){
            console.log(result);
            console.log(error);
        });

    } catch (error) {
        alert( `Failed to Register Delivery Executive`);
        console.error(error)
    }

}

async function handleCustomerUpdateRequest(){

    let cusPhone =  document.getElementById("newCusPhone");

        let phone  = cusPhone.value;

        let accounts = await window.web3.eth.getAccounts();

        try {
            await mainContract.methods.UpdateCustomerNumber(phone).send({from: accounts[0]}, function(error, result){
            console.log(result);
            console.log(error);
        });

    } catch (error) {
        alert( `Only Customers can access this portal`);
        console.error(error)
    }

}

async function handleHotelUpdateRequest(){

    let Phone =  document.getElementById("newHotelPhone");

        let phone  = Phone.value;

        let accounts = await window.web3.eth.getAccounts();

        try {
            await mainContract.methods.UpdateHotelNumber(phone).send({from: accounts[0]}, function(error, result){
            console.log(result);
            console.log(error);
        });

    } catch (error) {
        alert( `Only Hotel Management can access this portal`);
        console.error(error)
    }

}

async function handleExecUpdateRequest(){

    let Phone =  document.getElementById("newExecPhone");

        let phone  = Phone.value;

        let accounts = await window.web3.eth.getAccounts();

        try {
            await mainContract.methods.UpdateExecutiveNumber(phone).send({from: accounts[0]}, function(error, result){
            console.log(result);
            console.log(error);
        });

    } catch (error) {
        alert( `Only Delivery Executive can access this portal`);
        console.error(error)
    }

}


async function handleAddItemRequest() {
    
    let item = document.getElementById("itemName");

    let rate = document.getElementById("itemPrice");

    let name = item.value;

    let price = rate.value;


    let accounts = await window.web3.eth.getAccounts();



    try {

        
        await mainContract.methods.addItem(name, price).send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( `Unable to Add Item into the Menu`);
    console.error(error)
}

    
}

async function handleUpdateItemRequest() {
    
    let item = document.getElementById("updateItemName");

    let rate = document.getElementById("newPrice");

    let name = item.value;

    let price = rate.value;


    let accounts = await window.web3.eth.getAccounts();

    try {
        await mainContract.methods.updateMenu(name, price).send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( `Please select Item Available in the Menu`);
    console.error(error)
}
    
}

async function handleRemoveItemRequest() {
    
    let item = document.getElementById("removeditemName");


    let name = item.value;



    let accounts = await window.web3.eth.getAccounts();

    try {
        await mainContract.methods.RemoveItem(name).send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( `Please select Item Available in the Menu to Remove`);
    console.error(error)
}
    
}

async function handleSelectItemRequest() {
    
    let item = document.getElementById("selectedItemName");


    let name = item.value;



    let accounts = await window.web3.eth.getAccounts();

    try {
        await mainContract.methods.Add_to_cart(name).send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( `Please select Item Available in the Menu `);
    console.error(error)
}
    
}


async function handleViewBillRequest() {


    let accounts = await window.web3.eth.getAccounts();

    try {
        await mainContract.methods.view_Bill().send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( ` No Items added in the Cart `);
    console.error(error)
}
    
}

async function handlePrepareRequest() {


    let accounts = await window.web3.eth.getAccounts();

    try {
        await token.methods.approve(mainContract._address,1000000000000000).send({from: accounts[0]});

        await mainContract.methods.Prepare_Food().send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( `Unable to Prepare Food Item`);
    console.error(error)
}
    
}


async function handleAuthRequest() {


    let accounts = await window.web3.eth.getAccounts();

    try {
        await token.methods.approve(mainContract._address,1000000000000000).send({from: accounts[0]});
        await mainContract.methods.Auth_Hotel(true).send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( `HoteL Management Unable to Authenticate`);
    console.error(error)
}
    
}

async function handlePickOrderRequest() {

    let accounts = await window.web3.eth.getAccounts();

    try {
                await token.methods.approve(mainContract._address,1000000000000000).send({from: accounts[0]});

        await mainContract.methods.Pick_Order().send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( `Delivery Executive Unable to Pickup Order`);
    console.error(error)
}

}

async function handleCheckOutRequest() {


    let accounts = await window.web3.eth.getAccounts();

    try {
        await token.methods.approve(mainContract._address,1000000000000000).send({from: accounts[0]});
        await mainContract.methods.Confirm_and_Checkout(true).send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( `Customer Unable to Pay and Order`);
    console.error(error)
}

}

async function handleAuthCusRequest() {

    let accounts = await window.web3.eth.getAccounts();

    try {
        await mainContract.methods.Auth_Customer(true).send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( `Customer Unable to Authenticate`);
    console.error(error)
}

}


async function handleAuthExecRequest() {

    let accounts = await window.web3.eth.getAccounts();

    try {
        await token.methods.approve(mainContract._address,1000000000000000).send({from: accounts[0]});
        await mainContract.methods.Auth_Executive(true).send({from: accounts[0]}, function(error, result){
        console.log(result);
        console.log(error);
    });

} catch (error) {
    alert( `Executive Unable to Authenticate`);
    console.error(error)
}



}

window.addEventListener('DOMContentLoaded', initialize);
