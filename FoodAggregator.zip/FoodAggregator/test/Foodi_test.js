const MainContract = artifacts.require("MainContract");
const foodiToken = artifacts.require("foodiToken");
const CustomerRegistration = artifacts.require("CustomerRegistration");
const HotelRegistration = artifacts.require("HotelRegistration");
const ExecutiveRegistration = artifacts.require("ExecutiveRegistration");
const truffleAssert = require("truffle-assertions");


///////////////////////// Token Testing -Start ///////////////////////////


contract('Test foodi contract for buying fOOdi Tokens', (accounts) => {

  let owner = accounts[0];
  let buyer = accounts[1];

  it('Test Main_foodi contract is intialized', async () => {
    const main = await MainContract.deployed();
    const foodi = await foodiToken.deployed();

    const balance = await foodi.balanceOf(owner);

    assert.equal(balance.valueOf(), 100000000000000000000, "100 Foodi Tokens wasn't in the first account");
  });

  it('If buy was succesfull', async () => {
    const main = await MainContract.deployed();
    const foodi = await foodiToken.deployed();

    await main._setToken(foodi.address);
    await foodi.approve(main.address,1000000);

    let response = await main._buyTokens(1000,{from: buyer, value: 10000000000000000000});
    truffleAssert.eventEmitted(response, 'TOKENTRANSFERED', (ev) => {
        return ev.buyer == buyer && ev.sender == owner && ev.amount == 1000 ;
      });
  

    const balance = await foodi.balanceOf(buyer);

    assert.equal(balance.valueOf(), 1000, "1000 Tokens wasn't in the first account");
  });

  it('Buy was not succesfull as enough ether is not sent', async () => {
    const main = await MainContract.deployed();
    const foodi = await foodiToken.deployed();

    await main._setToken(foodi.address);
    await foodi.approve(main.address,1000000);

    try{
      await main._buyTokens(1000,{from: buyer, value: 1000});
      assert.fail("Revert: Buy Tokens should have failed for cutoff ether value")  
    }catch(err){
      assert.include(err.message, "Send atleast 1 ether to Buy a Token", "The error message should contain 'revert'");
    }

  });

});


// ////////////////////// Token Testing -end////////////////////////



// ////////////////////// Registration Testing -Start////////////////////////


contract('Testing Registration Process', (accounts) => {

  let user = accounts[0];
  

  it('Test Customer is registered', async () => {
    const main = await CustomerRegistration.deployed();
    

    let response = await main.Register_as_Customer("Subash","Coimbatore",994281155,{from: user});
    truffleAssert.eventEmitted(response, 'CustomerRegistered', (ev) => {
        return ev.who == user && ev.Name == "Subash" && ev.contactaddress == "Coimbatore" && ev.number ==  994281155;
      });

      const res  = await main.CheckCustomerExist(user);

      assert.equal(res, "true", "Customer Registration Failed");
  });

  it('Test Hotel Management is registered', async () => {
    const main = await HotelRegistration.deployed();
    

    let response = await main.Register_as_Hotel("AnnaPoorna","Coimbatore",994281155,{from: user});
    truffleAssert.eventEmitted(response, 'HotelRegistered', (ev) => {
        return ev.who == user && ev.Name == "AnnaPoorna" && ev.contactaddress == "Coimbatore" && ev.number ==  994281155;
      });

      const res  = await main.CheckHotelExist(user);

      assert.equal(res, "true", "Hotel Registration Failed");
  });

  it('Test Executive is registered', async () => {
    const main = await ExecutiveRegistration.deployed();
    

    let response = await main.Register_as_DeliveryExecutive("Subash","Coimbatore",994281155,{from: user});
    truffleAssert.eventEmitted(response, 'ExecutiiveRegistered', (ev) => {
        return ev.who == user && ev.Name == "Subash" && ev.contactaddress == "Coimbatore" && ev.number ==  994281155;
      });

      const res  = await main.CheckUserExist(user);

      assert.equal(res, "true", "Executive Registration Failed");
  });

});

// ////////////////////// Registration Testing -end////////////////////////



// ////////////////////// Hotel Testing -Start////////////////////////



contract('Testing Hotel Management Operations', (accounts) => {

  let customer = accounts[0];
  let hotel = accounts[1];
  let exec = accounts[2];
  

  it('Test Hotel management is able to add items into menu', async () => {
    const main = await HotelRegistration.deployed();
    
    await main.Register_as_Hotel("AnnaPoorna","Coimbatore",994281155,{from: hotel});
    let response = await main.addItem("Idly",100,{from: hotel});

      const res  = await main.CheckItemExist("Idly");

      assert.equal(res, 100, "Item is not uploaded into the Menu");
  });

  it('Test Hotel management is able to update rate of items in menu', async () => {
    const main = await HotelRegistration.deployed();
    
    await main.Register_as_Hotel("AnnaPoorna","Coimbatore",994281155,{from: hotel});
    await main.addItem("Idly",100,{from: hotel});
    let response = await main.updateMenu("Idly",150,{from: hotel});

      const res  = await main.CheckItemExist("Idly");

      assert.equal(res, 150, "Item price is not updated in the Menu");
  }); 
  
    // it('Test Hotel is able to pick and Prepare ordered food', async () => {

    //   const main = await MainContract.deployed();
    //   const foodi = await foodiToken.deployed();
  
    //   await main._setToken(foodi.address);
    //   await foodi.approve(main.address,1000000);
  
    //   await main._buyTokens(100,{from: customer, value: 10000000000000000000});
    //   await main._buyTokens(100,{from:    hotel, value: 10000000000000000000});

    //   await main.Register_as_Hotel("AnnaPoorna","Coimbatore",994281155,{from: hotel});
    //   await main.addItem("Idly",100,{from: hotel});
    //   await main.Register_as_Customer("Subash","Coimbatore",994281155,{from: customer});
  
    //   await main.Add_to_cart("Idly",{from: customer});
    //   await main.Confirm_and_Checkout(true,{from: customer});

    //     const prepare = await main.Prepare_Food({from: hotel});
  
    //     const res  = await main.checkPrepare(prepare,{from: hotel});
  
    //     assert.equal(res, "true", "Hotel Management Unable to pick and Prepare ordered Item");
    // });

  });

// ////////////////////// Hotel Testing -end////////////////////////



// ////////////////////// Customer Testing -Start////////////////////////


contract('Testing Customer Functions', (accounts) => {

  let customer = accounts[0];
  let hotel = accounts[1];
  let exec = accounts[2];
  

  it('Test Customer is able to order an item', async () => {
    // const main = await HotelRegistration.deployed();
    const main = await MainContract.deployed();
    const foodi = await foodiToken.deployed();

    await main._setToken(foodi.address);
    await foodi.approve(main.address,1000000);

    await main._buyTokens(1000,{from: customer, value: 10000000000000000000});
    
    await main.Register_as_Hotel("AnnaPoorna","Coimbatore",994281155,{from: hotel});
    await main.addItem("Idly",100,{from: hotel});
    await main.Register_as_Customer("Subash","Coimbatore",994281155,{from: customer});

    await main.Add_to_cart("Idly",{from: customer});

      const res  = await main.checkItem(100);

      assert.equal(res, "true", "Customer Unable to order Item");
  });

  // it('Test Customer is able Authenticate Transfer Token', async () => {
  //   const main = await MainContract.deployed();
  //   const foodi = await foodiToken.deployed();

  //   await main._setToken(foodi.address);
  //   await foodi.approve(main.address,1000000);

  //   await main._buyTokens(1000,{from: customer, value: 10000000000000000000});
    
  //   await main.Register_as_Hotel("AnnaPoorna","Coimbatore",994281155,{from: hotel});
  //   await main.addItem("Idly",100,{from: hotel});
  //   await main.Register_as_Customer("Subash","Coimbatore",994281155,{from: customer});

  //   await main.Register_as_DeliveryExecutive("Shanjay","Coimbatore",994281155,{from: exec});
  //   await main._buyTokens(1000,{from: exec, value: 10000000000000000000});

  //   await main.Add_to_cart("Idly",{from: customer});
  //   await main.Pick_Order({from: exec});

  //   await main.Auth_Customer(true,{from: customer});

   



  //     const res  = await main.checkAuth();

  //     assert.equal(res, "true", "Customer Unable to Authenticate Transfer");
  // });


});



// ////////////////////// Customer Testing -end////////////////////////



// ////////////////////// Executive Testing -start////////////////////////



    contract('Testing Delivery Executive Functions', (accounts) => {

      let customer = accounts[0];
      let hotel = accounts[1];
      let exec = accounts[2];
      
    
      it('Test Delivery Executive is able to pick an ordered item', async () => {
        const main = await MainContract.deployed();
        const foodi = await foodiToken.deployed();
    
        await main._setToken(foodi.address);
        await foodi.approve(main.address,1000000);
    
        await main._buyTokens(1000,{from: customer, value: 10000000000000000000});
        
        await main.Register_as_Hotel("AnnaPoorna","Coimbatore",994281155,{from: hotel});
        await main.addItem("Idly",100,{from: hotel});
        await main.Register_as_Customer("Subash","Coimbatore",994281155,{from: customer});
    

        await main.Register_as_DeliveryExecutive("Shanjay","Coimbatore",994281155,{from: exec});
        await main._buyTokens(1000,{from: exec, value: 10000000000000000000});

    
        await main.Add_to_cart("Idly",{from: customer});

        const pick = await main.Pick_Order({from: exec});
    
        const res  = await main.checkPick(pick,{from: exec});
    
          assert.equal(res, "true", "Delivery Executive Unable to pick the ordered Item");
      });
    
      // it('Test Customer is able Authenticate Transfer Token', async () => {
      //   const main = await MainContract.deployed();
      //   const foodi = await foodiToken.deployed();
    
      //   await main._setToken(foodi.address);
      //   await foodi.approve(main.address,1000000);
    
      //   await main._buyTokens(1000,{from: customer, value: 10000000000000000000});
        
      //   await main.Register_as_Hotel("AnnaPoorna","Coimbatore",994281155,{from: hotel});
      //   await main.addItem("Idly",100,{from: hotel});
      //   await main.Register_as_Customer("Subash","Coimbatore",994281155,{from: customer});
    
      //   await main.Add_to_cart("Idly",{from: customer});
    
      //   await main.Auth_Customer(true,{from: customer});
    
    
    
      //     const res  = await main.checkAuth();
    
      //     assert.equal(res, "true", "Customer Unable to Authenticate Transfer");
      // });
    
    
    });

    // ////////////////////// Executive Testing - end ////////////////////////
