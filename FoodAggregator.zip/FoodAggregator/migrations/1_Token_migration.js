const foodiToken = artifacts.require("foodiToken");


module.exports = function (deployer) {

  deployer.deploy(foodiToken,"Foodi","fOOdi",100);

};
