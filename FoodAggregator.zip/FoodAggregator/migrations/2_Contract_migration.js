const CustomerRegistration = artifacts.require("CustomerRegistration");
const HotelRegistration = artifacts.require("HotelRegistration");
const ExecutiveRegistration = artifacts.require("ExecutiveRegistration");
const MainContract = artifacts.require("MainContract");
const foodiToken = artifacts.require("foodiToken");

module.exports = async function (deployer) {


  const foodi = await foodiToken.deployed("Foodi","fOOdi",100);

  deployer.deploy(CustomerRegistration);
  deployer.deploy(HotelRegistration);
  deployer.deploy(ExecutiveRegistration);
  const main = await deployer.deploy(MainContract);
  await main._setToken(foodi.address);
  await foodi.approve(main.address,1000000000000000);
  
};